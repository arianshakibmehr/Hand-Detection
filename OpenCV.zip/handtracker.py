import cv2
import mediapipe as mp
import math
import numpy as np

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

def calculate_distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

# تابعی برای اندازه گیری فاصله انگشت تا کدر شدن (0 تا 1)
def calculate_opacity(distance, min_dist=20, max_dist=200):
    if distance < min_dist:
        return 1 
    elif distance > max_dist:
        return 0 
    else:
        return 1 - (distance - min_dist) / (max_dist - min_dist)

# باز کردن دوربین و دسترسی از سیستم
cap = cv2.VideoCapture(0)

image_path = 'cyrus.jpg'  
image = cv2.imread(image_path)

if image is None:
    print(f"Error: Unable to load image at path '{image_path}'. Check the file path.")
    cap.release()
    cv2.destroyAllWindows()
    exit()

image = cv2.resize(image, (640, 480))

# ایجاد یک صفحه سیاه
black_cover = np.zeros_like(image, dtype=np.uint8)

while cap.isOpened():
    success, frame = cap.read()
    if not success:
        print("Error: Unable to capture video frame from camera.")
        break


    frame = cv2.flip(frame, 1)
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(frame_rgb)

    # تیرگی کاور (کاملاً مات)
    cover_opacity = 1

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP]
            index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]

            # تبدیل مختصات به پیکسل
            thumb_x = int(thumb_tip.x * frame.shape[1])
            thumb_y = int(thumb_tip.y * frame.shape[0])
            index_x = int(index_tip.x * frame.shape[1])
            index_y = int(index_tip.y * frame.shape[0])

            # فاصله بین انگشت شست و اشاره را محاسبه کنید
            distance = calculate_distance(thumb_x, thumb_y, index_x, index_y)

            cover_opacity = calculate_opacity(distance)

            cv2.circle(frame, (thumb_x, thumb_y), 10, (0, 255, 0), -1)
            cv2.circle(frame, (index_x, index_y), 10, (0, 255, 0), -1)

            # نمایش فاصله
            cv2.putText(frame, f'Distance: {int(distance)}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

    # پوشش مشکی با تیرگی متفاوت روی تصویر
    overlay = cv2.addWeighted(black_cover, cover_opacity, image, 1 - cover_opacity, 0)

    # نمایش تصویر اصلی
    cv2.imshow('Image with Black Cover', overlay)

    # نمایش قاب ردیابی دست در یک پنجره جداگانه 
    cv2.imshow('Hand Tracker', frame)

    # با فشار دادن 'q' خارج شوید
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# آزاد کردن منابع
cap.release()
cv2.destroyAllWindows()


# ArianShakibMehr